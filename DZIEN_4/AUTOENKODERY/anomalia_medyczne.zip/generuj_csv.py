"""
Generator zbioru danych medycznych -> CSV (5000 rekordów)
==========================================================
12 markerów biochemicznych + metadane pacjenta + etykieta.
~89% zdrowych / ~11% anomalii (4 wzorce patologii).

Kolumny etykiet (do walidacji, NIE do treningu autoenkodera):
  label      : 0 = zdrowy, 1 = anomalia
  pattern    : typ profilu (healthy / metaboliczny / nerkowy / ...)

Uwaga: dane SYNTETYCZNE. Zakresy i korelacje odwzorowują fizjologię
w sposób wiarygodny dydaktycznie, ale to nie są dane rzeczywistych pacjentów.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N_TOTAL = 5000
FRAKCJA_ANOMALII = 0.11
N_ANOM = int(N_TOTAL * FRAKCJA_ANOMALII)
N_ZDROWI = N_TOTAL - N_ANOM

MARKERY = ["glukoza", "hba1c", "cholesterol", "ldl", "hdl", "triglicerydy",
           "kreatynina", "egfr", "alt", "ast", "crp", "leukocyty"]

# jednostki — przydają się w nagłówku dla realizmu klinicznego
JEDNOSTKI = {
    "glukoza": "mg/dL", "hba1c": "%", "cholesterol": "mg/dL", "ldl": "mg/dL",
    "hdl": "mg/dL", "triglicerydy": "mg/dL", "kreatynina": "mg/dL",
    "egfr": "mL/min/1.73m2", "alt": "U/L", "ast": "U/L", "crp": "mg/L",
    "leukocyty": "10^3/uL",
}


def profil_zdrowy(n, wiek, plec):
    """Skorelowany rozkład fizjologiczny z wpływem wieku i płci."""
    # wiek delikatnie podnosi glukozę, ciśnienie metaboliczne, kreatyninę
    wiek_z = (wiek - 45) / 15.0

    glukoza     = np.random.normal(90, 8, n) + wiek_z * 3
    hba1c       = 4.5 + (glukoza - 90) * 0.03 + np.random.normal(0, 0.3, n)
    cholesterol = np.random.normal(185, 25, n) + wiek_z * 8
    ldl         = cholesterol * 0.6 + np.random.normal(0, 12, n)
    # HDL: kobiety statystycznie wyżej
    hdl         = np.random.normal(55, 10, n) - (cholesterol - 185) * 0.05 \
                  + np.where(plec == "K", 6, 0)
    tg          = np.random.normal(120, 35, n) + (glukoza - 90) * 1.2
    # kreatynina: mężczyźni wyżej (masa mięśniowa)
    kreatynina  = np.random.normal(0.9, 0.15, n) + np.where(plec == "M", 0.15, 0)
    egfr        = 120 - (kreatynina - 0.9) * 80 - wiek_z * 5 \
                  + np.random.normal(0, 8, n)
    alt         = np.random.normal(25, 8, n) + np.where(plec == "M", 4, 0)
    ast         = alt * 0.9 + np.random.normal(0, 5, n)
    crp         = np.abs(np.random.normal(1.5, 1.0, n))
    leukocyty   = np.random.normal(7, 1.5, n)

    return np.column_stack([glukoza, hba1c, cholesterol, ldl, hdl, tg,
                            kreatynina, egfr, alt, ast, crp, leukocyty])


def zaburz_patologia(wiersz, wzorzec):
    """Nakłada wzorzec chorobowy: łamie zakresy I korelacje."""
    w = wiersz.copy()
    if wzorzec == "metaboliczny":       # cukrzyca + dyslipidemia
        w[0] *= np.random.uniform(1.4, 2.2)    # glukoza
        w[1] *= np.random.uniform(1.5, 2.0)    # HbA1c
        w[5] *= np.random.uniform(2.0, 3.5)    # triglicerydy
        w[4] *= np.random.uniform(0.5, 0.8)    # HDL w dół
    elif wzorzec == "nerkowy":          # niewydolność nerek
        w[6] *= np.random.uniform(2.5, 5.0)    # kreatynina
        w[7] *= np.random.uniform(0.3, 0.5)    # eGFR w dół
        w[10] *= np.random.uniform(2.0, 4.0)   # CRP lekko w górę
    elif wzorzec == "watrobowy":        # uszkodzenie wątroby
        w[8] *= np.random.uniform(4.0, 10.0)   # ALT
        w[9] *= np.random.uniform(4.0, 10.0)   # AST
    elif wzorzec == "zapalny":          # stan zapalny / sepsa
        w[10] *= np.random.uniform(8.0, 25.0)  # CRP
        w[11] *= np.random.uniform(2.0, 3.5)   # leukocyty
    return w


# ---- Metadane pacjentów -----------------------------------------------
wiek = np.clip(np.random.normal(48, 16, N_TOTAL), 18, 92).astype(int)
plec = np.random.choice(["M", "K"], N_TOTAL)

# ---- Budowa macierzy markerów -----------------------------------------
X = profil_zdrowy(N_TOTAL, wiek, plec)

label = np.zeros(N_TOTAL, dtype=int)
pattern = np.array(["healthy"] * N_TOTAL, dtype=object)

# losowo wybierz indeksy anomalii
idx_anom = np.random.choice(N_TOTAL, N_ANOM, replace=False)
wzorce = ["metaboliczny", "nerkowy", "watrobowy", "zapalny"]
for i in idx_anom:
    wz = np.random.choice(wzorce)
    X[i] = zaburz_patologia(X[i], wz)
    label[i] = 1
    pattern[i] = wz

# ---- Realistyczne artefakty danych ------------------------------------
# 1) zaokrąglenia zgodne z praktyką laboratoryjną
zaokraglenia = {"glukoza": 0, "hba1c": 1, "cholesterol": 0, "ldl": 0,
                "hdl": 0, "triglicerydy": 0, "kreatynina": 2, "egfr": 0,
                "alt": 0, "ast": 0, "crp": 1, "leukocyty": 1}

df = pd.DataFrame(X, columns=MARKERY)
for kol, miejsca in zaokraglenia.items():
    df[kol] = df[kol].round(miejsca)
    if miejsca == 0:
        df[kol] = df[kol].astype(int)

# odetnij wartości fizycznie niemożliwe (ujemne)
for kol in MARKERY:
    df[kol] = df[kol].clip(lower=0)

# 2) braki danych (~1.5% losowo, jak w realnych zbiorach)
#    NIE dotykamy etykiet — tylko pomiarów
maska_braki = np.random.random(df[MARKERY].shape) < 0.015
df_markery = df[MARKERY].mask(maska_braki)
df[MARKERY] = df_markery

# ---- Kolumny opisowe --------------------------------------------------
df.insert(0, "patient_id", [f"P{100000 + i}" for i in range(N_TOTAL)])
df.insert(1, "wiek", wiek)
df.insert(2, "plec", plec)
df["label"] = label
df["pattern"] = pattern

# przetasuj wiersze (anomalie rozproszone, nie na końcu)
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

# ---- Zapis ------------------------------------------------------------
sciezka = "dane_medyczne_5000.csv"
df.to_csv(sciezka, index=False)

# ---- Podsumowanie -----------------------------------------------------
print(f"Zapisano: {sciezka}")
print(f"Rekordów: {len(df)}")
print(f"Zdrowi:   {(df.label == 0).sum()}  ({(df.label == 0).mean():.1%})")
print(f"Anomalie: {(df.label == 1).sum()}  ({(df.label == 1).mean():.1%})")
print(f"\nRozkład wzorców patologii:")
print(df[df.label == 1]["pattern"].value_counts().to_string())
print(f"\nBraki danych: {df[MARKERY].isna().sum().sum()} komórek "
      f"({df[MARKERY].isna().sum().sum() / (len(df)*12):.1%})")
print(f"\nPodgląd (pierwsze 5 wierszy):")
print(df.head().to_string())
print(f"\nStatystyki markerów (zdrowi vs anomalie) — glukoza i kreatynina:")
for kol in ["glukoza", "kreatynina", "alt", "crp"]:
    z = df[df.label == 0][kol].mean()
    a = df[df.label == 1][kol].mean()
    print(f"  {kol:12s}  zdrowi={z:7.1f}   anomalie={a:7.1f}")
