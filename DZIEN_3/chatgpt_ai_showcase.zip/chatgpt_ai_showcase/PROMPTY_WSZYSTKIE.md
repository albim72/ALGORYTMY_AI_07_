# Prompty do pięciu pokazów

Każdy katalog zawiera własny `prompt.txt`. Kolejność prezentacji:

1. Obraz → formalny graf → symulator.
2. Model 99% → audyt przecieku danych.
3. NeuroDSL → lexer, parser, AST i dwa backendy.
4. Screenshot + logi + kod → autopsja awarii.
5. Agent + narzędzia → autonomiczny eksperyment ML.
