namespace DemoApp;

public sealed class UserService
{
    private readonly MemoryCache _cache;
    private readonly IUserRepository _repository;
    private readonly RetryPolicy _retry;

    public UserService(MemoryCache cache, IUserRepository repository, RetryPolicy retry)
    {
        _cache = cache;
        _repository = repository;
        _retry = retry;
    }

    public Task<User> GetUserAsync(int id) =>
        _retry.ExecuteAsync(async () =>
        {
            var key = $"user:{id}";
            var cached = _cache.Get(key);
            if (cached is User user)
            {
                return user;
            }

            user = await _repository.LoadUserAsync(id);
            _cache.Set(key, user);
            return user;
        });
}
