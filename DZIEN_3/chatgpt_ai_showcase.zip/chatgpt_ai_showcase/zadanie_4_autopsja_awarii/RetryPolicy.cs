namespace DemoApp;

public sealed class RetryPolicy
{
    private readonly int _maxRetries;
    private readonly int _baseDelayMs;

    public RetryPolicy(int maxRetries, int baseDelayMs)
    {
        _maxRetries = maxRetries;
        _baseDelayMs = baseDelayMs;
    }

    public async Task<T> ExecuteAsync<T>(Func<Task<T>> action)
    {
        for (var attempt = 0; ; attempt++)
        {
            try
            {
                return await action();
            }
            catch (Exception) when (attempt < _maxRetries)
            {
                // BUG: retrying programmer/concurrency errors hides and amplifies the failure.
                await Task.Delay(_baseDelayMs * (attempt + 1));
            }
        }
    }
}
