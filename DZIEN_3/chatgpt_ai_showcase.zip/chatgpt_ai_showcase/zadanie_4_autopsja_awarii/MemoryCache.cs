namespace DemoApp;

public sealed class MemoryCache
{
    private sealed record Entry(object Value, DateTime ExpiresAtUtc);

    private readonly Dictionary<string, Entry> _store = new();
    private readonly Timer _cleanupTimer;
    private readonly TimeSpan _ttl;

    public MemoryCache(TimeSpan ttl, TimeSpan cleanupInterval)
    {
        _ttl = ttl;
        _cleanupTimer = new Timer(
            _ => CleanupExpired(),
            null,
            cleanupInterval,
            cleanupInterval);
    }

    public object? Get(string key)
    {
        // BUG: check-then-act on a Dictionary shared with the timer thread.
        if (!_store.ContainsKey(key))
        {
            return null;
        }

        var entry = _store[key];

        // BUG: local clock is compared with an UTC timestamp.
        if (entry.ExpiresAtUtc <= DateTime.Now)
        {
            _store.Remove(key);
            return null;
        }

        return entry.Value;
    }

    public void Set(string key, object value)
    {
        _store[key] = new Entry(value, DateTime.UtcNow.Add(_ttl));
    }

    private void CleanupExpired()
    {
        foreach (var pair in _store)
        {
            if (pair.Value.ExpiresAtUtc <= DateTime.UtcNow)
            {
                _store.Remove(pair.Key);
            }
        }
    }
}
