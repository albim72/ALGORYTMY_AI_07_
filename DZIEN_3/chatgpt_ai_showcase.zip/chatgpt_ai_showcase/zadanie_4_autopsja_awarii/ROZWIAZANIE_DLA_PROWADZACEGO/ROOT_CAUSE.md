# Główna przyczyna

`MemoryCache` używa zwykłego `Dictionary` równocześnie z wątku żądania i timera.

Najbardziej bezpośredni wyścig:

1. `Get` wykonuje `ContainsKey(key)` i otrzymuje `true`.
2. Timer usuwa wpis.
3. `Get` wykonuje `_store[key]`.
4. Powstaje `KeyNotFoundException`.

Dodatkowe błędy:

- usuwanie elementów podczas iterowania po `Dictionary`,
- mieszanie `DateTime.Now` z `DateTime.UtcNow`,
- retry wszystkich wyjątków, także błędów programistycznych,
- cache stampede przy równoczesnym braku wpisu.
