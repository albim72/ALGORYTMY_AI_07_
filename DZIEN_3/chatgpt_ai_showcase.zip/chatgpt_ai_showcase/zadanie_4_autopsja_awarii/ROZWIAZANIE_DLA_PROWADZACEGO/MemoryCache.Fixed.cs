using System.Collections.Concurrent;

namespace DemoApp;

public sealed class MemoryCache
{
    private sealed record Entry(object Value, DateTime ExpiresAtUtc);
    private readonly ConcurrentDictionary<string, Entry> _store = new();
    private readonly TimeSpan _ttl;

    public MemoryCache(TimeSpan ttl)
    {
        _ttl = ttl;
    }

    public object? Get(string key)
    {
        if (!_store.TryGetValue(key, out var entry))
        {
            return null;
        }

        if (entry.ExpiresAtUtc <= DateTime.UtcNow)
        {
            _store.TryRemove(key, out _);
            return null;
        }

        return entry.Value;
    }

    public void Set(string key, object value) =>
        _store[key] = new Entry(value, DateTime.UtcNow.Add(_ttl));
}
