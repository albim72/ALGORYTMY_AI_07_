# ChatGPT AI Showcase: pakiet szkoleniowy

Gotowy zestaw pięciu demonstracji dla programistów i zaawansowanych twórców.

## Zawartość

- `00_plansza_glowna.png` — plansza otwierająca pokaz.
- `zadanie_1_symulator` — odręczny diagram, formalna specyfikacja i analizator.
- `zadanie_2_oszustwo_ml` — CSV/XLSX z przeciekiem, driftem i duplikatami.
- `zadanie_3_kompilator_ndsl` — język NeuroDSL, kompilator i testy.
- `zadanie_4_autopsja_awarii` — screenshot, logi, YAML i kod C# z race condition.
- `zadanie_5_agent_ml_mcp` — specyfikacja narzędzi i deterministyczny serwer laboratoryjny.

## Zalecana dramaturgia

1. Zacznij od obrazu. Nie ujawniaj plików z rozwiązaniami.
2. W zadaniu ML najpierw pozwól modelowi zachwycić się wynikiem.
3. Kompilator pokaż jako przejście od tekstu do AST i kodu.
4. Przy awarii wymagaj hipotez i falsyfikacji przed patchem.
5. Na koniec pokaż agenta, który sam wybiera eksperymenty, ale zatrzymuje się
   przed działaniem wymagającym zgody człowieka.

## Środowisko

Python 3.11+.

Instaluj zależności osobno w katalogach z plików `requirements.txt`.
Każdy pokaz może być prowadzony wyłącznie przez wgrywanie plików do ChatGPT,
bez lokalnego uruchamiania kodu.
