# Zadanie 1: obraz → graf → symulator

1. Pokaż `whiteboard_process.png`.
2. Wgraj obraz do ChatGPT razem z `prompt.txt`.
3. Nie pokazuj od razu `process_spec.json`.
4. Po analizie porównaj wynik modelu z plikiem `ROZWIAZANIE.md`.

Efekt „wow”: model musi połączyć widzenie, formalizację grafu, analizę algorytmiczną,
generowanie kodu oraz testowanie.
