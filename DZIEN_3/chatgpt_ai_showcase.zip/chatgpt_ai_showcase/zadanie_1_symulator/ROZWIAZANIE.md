# Celowo zaszyte anomalie

- `ManualReview` i `Archive` są stanami nieosiągalnymi.
- `WaitForPayment` jest deadlockiem.
- Z `Validate` wychodzą dwa przejścia z identycznym warunkiem `score >= 70`.
- `Validate → Retry → Validate` tworzy cykl.
- `Reject` i `WaitForPayment` nie mają ścieżki do `END`.
