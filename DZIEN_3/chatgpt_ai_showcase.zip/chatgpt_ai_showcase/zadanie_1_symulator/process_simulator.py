"""Reference state-machine analyzer used by the instructor."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import networkx as nx


class ProcessModel:
    """Load, analyze and simulate a directed process graph."""

    def __init__(self, specification: dict[str, Any]) -> None:
        self.specification = specification
        self.graph = nx.DiGraph()
        self.graph.add_nodes_from(specification["states"])
        for transition in specification["transitions"]:
            self.graph.add_edge(
                transition["from"],
                transition["to"],
                condition=transition["condition"],
            )

    def analyze(self) -> dict[str, Any]:
        initial = self.specification["initial"]
        finals = set(self.specification["final_states"])
        reachable = nx.descendants(self.graph, initial) | {initial}
        unreachable = sorted(set(self.graph.nodes) - reachable)
        deadlocks = sorted(
            node for node in reachable
            if self.graph.out_degree(node) == 0 and node not in finals
        )
        cycles = [cycle for cycle in nx.simple_cycles(self.graph)]

        conflicts: list[dict[str, str]] = []
        grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
        for source, target, data in self.graph.edges(data=True):
            grouped[(source, data["condition"])].append(target)
        for (source, condition), targets in grouped.items():
            if len(targets) > 1:
                conflicts.append(
                    {"state": source, "condition": condition, "targets": ", ".join(targets)}
                )

        cannot_reach_final = []
        for node in reachable:
            if node in finals:
                continue
            if not any(nx.has_path(self.graph, node, final) for final in finals):
                cannot_reach_final.append(node)

        return {
            "unreachable": unreachable,
            "deadlocks": deadlocks,
            "cycles": cycles,
            "conflicts": conflicts,
            "cannot_reach_final": sorted(cannot_reach_final),
        }


if __name__ == "__main__":
    spec_path = Path(__file__).with_name("process_spec.json")
    model = ProcessModel(json.loads(spec_path.read_text(encoding="utf-8")))
    print(json.dumps(model.analyze(), indent=2, ensure_ascii=False))
