"""A compact, dependency-free compiler for the NeuroDSL training language."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import sys


ACTIVATIONS = {"relu", "gelu", "sigmoid", "tanh", "softmax", "linear"}


class CompileError(ValueError):
    """Raised for lexical, syntax or semantic errors."""


@dataclass(frozen=True)
class Layer:
    """A single neural-network layer."""

    kind: str
    units: int | None
    activation: str | None
    rate: float | None
    line: int


@dataclass(frozen=True)
class Model:
    """NeuroDSL abstract syntax tree."""

    name: str
    layers: tuple[Layer, ...]


MODEL_RE = re.compile(r"^model\s+([A-Za-z_]\w*)\s*\{$")
INPUT_RE = re.compile(r"^input\s+(-?\d+)$")
DENSE_RE = re.compile(r"^dense\s+(-?\d+)\s+activation=([A-Za-z_]\w*)$")
DROPOUT_RE = re.compile(r"^dropout\s+([0-9]*\.?[0-9]+)$")
OUTPUT_RE = re.compile(r"^output\s+(-?\d+)\s+activation=([A-Za-z_]\w*)$")


def parse(source: str) -> Model:
    """Parse source code and return a validated AST."""
    raw_lines = source.splitlines()
    lines = [(index + 1, line.strip()) for index, line in enumerate(raw_lines) if line.strip()]
    if not lines:
        raise CompileError("line 1: empty source")

    match = MODEL_RE.match(lines[0][1])
    if not match:
        raise CompileError(f"line {lines[0][0]}: expected 'model Name {{'")
    name = match.group(1)

    if lines[-1][1] != "}":
        raise CompileError(f"line {lines[-1][0]}: expected closing '}}'")

    layers: list[Layer] = []
    for line_number, line in lines[1:-1]:
        match = INPUT_RE.match(line)
        if match:
            layers.append(Layer("input", int(match.group(1)), None, None, line_number))
            continue
        match = DENSE_RE.match(line)
        if match:
            layers.append(Layer("dense", int(match.group(1)), match.group(2), None, line_number))
            continue
        match = DROPOUT_RE.match(line)
        if match:
            layers.append(Layer("dropout", None, None, float(match.group(1)), line_number))
            continue
        match = OUTPUT_RE.match(line)
        if match:
            layers.append(Layer("output", int(match.group(1)), match.group(2), None, line_number))
            continue
        raise CompileError(f"line {line_number}: cannot parse: {line}")

    validate(layers)
    return Model(name, tuple(layers))


def validate(layers: list[Layer]) -> None:
    """Perform semantic validation."""
    inputs = [layer for layer in layers if layer.kind == "input"]
    outputs = [layer for layer in layers if layer.kind == "output"]
    if len(inputs) != 1:
        raise CompileError(f"semantic: expected exactly one input layer, found {len(inputs)}")
    if layers[0].kind != "input":
        raise CompileError(f"line {layers[0].line}: input must be the first layer")
    if len(outputs) != 1:
        raise CompileError(f"semantic: expected exactly one output layer, found {len(outputs)}")
    if layers[-1].kind != "output":
        raise CompileError(f"line {outputs[0].line}: output must be the last layer")

    for layer in layers:
        if layer.units is not None and layer.units <= 0:
            raise CompileError(f"line {layer.line}: units must be positive")
        if layer.activation and layer.activation not in ACTIVATIONS:
            raise CompileError(f"line {layer.line}: unknown activation '{layer.activation}'")
        if layer.kind == "dropout" and not (0.0 <= (layer.rate or 0.0) < 1.0):
            raise CompileError(f"line {layer.line}: dropout rate must be in [0, 1)")
        if layer.activation == "softmax" and layer.kind != "output":
            raise CompileError(f"line {layer.line}: softmax is allowed only in output")


def generate_keras(model: Model) -> str:
    """Generate TensorFlow/Keras source."""
    lines = [
        "from tensorflow import keras",
        "",
        f"model = keras.Sequential(name={model.name!r})",
    ]
    for layer in model.layers:
        if layer.kind == "input":
            lines.append(f"model.add(keras.layers.Input(shape=({layer.units},)))")
        elif layer.kind == "dense":
            lines.append(
                f"model.add(keras.layers.Dense({layer.units}, activation={layer.activation!r}))"
            )
        elif layer.kind == "dropout":
            lines.append(f"model.add(keras.layers.Dropout({layer.rate}))")
        elif layer.kind == "output":
            lines.append(
                f"model.add(keras.layers.Dense({layer.units}, activation={layer.activation!r}))"
            )
    return "\n".join(lines) + "\n"


def generate_pytorch(model: Model) -> str:
    """Generate illustrative PyTorch source."""
    input_units = next(layer.units for layer in model.layers if layer.kind == "input")
    lines = ["import torch.nn as nn", "", f"class {model.name}(nn.Module):", "    def __init__(self):", "        super().__init__()", "        self.layers = nn.Sequential("]
    previous = input_units
    activation_map = {
        "relu": "nn.ReLU()",
        "gelu": "nn.GELU()",
        "sigmoid": "nn.Sigmoid()",
        "tanh": "nn.Tanh()",
        "softmax": "nn.Softmax(dim=1)",
        "linear": "nn.Identity()",
    }
    for layer in model.layers[1:]:
        if layer.kind in {"dense", "output"}:
            lines.append(f"            nn.Linear({previous}, {layer.units}),")
            lines.append(f"            {activation_map[layer.activation]},")
            previous = layer.units
        elif layer.kind == "dropout":
            lines.append(f"            nn.Dropout({layer.rate}),")
    lines += ["        )", "", "    def forward(self, x):", "        return self.layers(x)"]
    return "\n".join(lines) + "\n"


def main() -> None:
    for filename in sys.argv[1:] or ["valid_program.ndsl"]:
        path = Path(filename)
        try:
            model = parse(path.read_text(encoding="utf-8"))
            print(model)
            print("\n--- KERAS ---")
            print(generate_keras(model))
            print("--- PYTORCH ---")
            print(generate_pytorch(model))
        except CompileError as error:
            print(f"{path}: {error}", file=sys.stderr)


if __name__ == "__main__":
    main()
