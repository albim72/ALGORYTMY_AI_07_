from pathlib import Path

import pytest

from neurodsl_compiler import CompileError, generate_keras, parse


ROOT = Path(__file__).parents[1]


def test_valid_program_compiles():
    model = parse((ROOT / "valid_program.ndsl").read_text(encoding="utf-8"))
    code = generate_keras(model)
    assert model.name == "IrisNet"
    assert "Dense(32" in code
    assert "softmax" in code


def test_invalid_program_is_rejected():
    with pytest.raises(CompileError):
        parse((ROOT / "invalid_program.ndsl").read_text(encoding="utf-8"))


def test_softmax_inside_hidden_layer_is_rejected():
    source = """
    model Wrong {
        input 4
        dense 8 activation=softmax
        output 3 activation=softmax
    }
    """
    with pytest.raises(CompileError, match="softmax"):
        parse(source)
