# Oczekiwany wynik

`valid_program.ndsl` powinien zostać zamieniony na AST i kod dwóch frameworków.

`invalid_program.ndsl` zawiera kilka błędów. Parser referencyjny zatrzyma się na
pierwszym błędzie semantycznym. Można poprosić ChatGPT o rozszerzenie kompilatora
o zbieranie wielu błędów w jednym przebiegu.
