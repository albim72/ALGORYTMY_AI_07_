# Co ma odkryć model

1. `future_retention_offer` i `closure_workflow_code` są przeciekiem celu.
2. Ten sam `customer_id` występuje w wielu miesiącach, więc random split przecieka klienta.
3. Około 3% rekordów jest dokładnymi duplikatami.
4. Dane od stycznia 2026 mają drift.
5. Accuracy nie wystarcza; trzeba pokazać PR-AUC i zachowanie na podziale czasowym.
