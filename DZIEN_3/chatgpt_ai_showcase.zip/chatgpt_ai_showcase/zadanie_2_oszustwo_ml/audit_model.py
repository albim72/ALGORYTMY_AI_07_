"""Demonstrates how a spectacular ML score collapses after leakage removal."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


TARGET = "target_churn_30d"
LEAK_COLUMNS = ["future_retention_offer", "closure_workflow_code"]


def evaluate(train: pd.DataFrame, test: pd.DataFrame, drop_leaks: bool) -> dict[str, float]:
    ignored = [TARGET, "customer_id", "snapshot_date"]
    if drop_leaks:
        ignored += LEAK_COLUMNS

    features = [column for column in train.columns if column not in ignored]
    x_train, y_train = train[features], train[TARGET]
    x_test, y_test = test[features], test[TARGET]

    categorical = x_train.select_dtypes(include="object").columns.tolist()
    numeric = [column for column in features if column not in categorical]

    preprocessing = ColumnTransformer(
        transformers=[
            ("num", SimpleImputer(strategy="median"), numeric),
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("encoder", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical,
            ),
        ]
    )
    model = Pipeline(
        steps=[
            ("preprocessing", preprocessing),
            (
                "classifier",
                RandomForestClassifier(
                    n_estimators=180,
                    max_depth=10,
                    min_samples_leaf=4,
                    class_weight="balanced",
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    model.fit(x_train, y_train)
    probability = model.predict_proba(x_test)[:, 1]
    prediction = (probability >= 0.5).astype(int)
    return {
        "accuracy": accuracy_score(y_test, prediction),
        "precision": precision_score(y_test, prediction, zero_division=0),
        "recall": recall_score(y_test, prediction, zero_division=0),
        "f1": f1_score(y_test, prediction, zero_division=0),
        "roc_auc": roc_auc_score(y_test, probability),
        "pr_auc": average_precision_score(y_test, probability),
    }


def main() -> None:
    data = pd.read_csv(Path(__file__).with_name("fraudulent_customers.csv"))
    data["snapshot_date"] = pd.to_datetime(data["snapshot_date"])

    train_random, test_random = train_test_split(
        data, test_size=0.25, stratify=data[TARGET], random_state=42
    )

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
    train_idx, test_idx = next(splitter.split(data, groups=data["customer_id"]))
    train_group, test_group = data.iloc[train_idx], data.iloc[test_idx]

    cutoff = pd.Timestamp("2026-01-01")
    train_time = data[data["snapshot_date"] < cutoff]
    test_time = data[data["snapshot_date"] >= cutoff]

    experiments = {
        "random_with_leak": evaluate(train_random, test_random, False),
        "group_without_leak": evaluate(train_group, test_group, True),
        "temporal_without_leak": evaluate(train_time, test_time, True),
    }
    print(pd.DataFrame(experiments).T.round(4))


if __name__ == "__main__":
    main()
