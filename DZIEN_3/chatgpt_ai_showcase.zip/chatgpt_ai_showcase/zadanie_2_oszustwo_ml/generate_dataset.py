# Zbiór został wygenerowany deterministycznie przez skrypt budujący pakiet.
# Najważniejsze pułapki:
# - future_retention_offer oraz closure_workflow_code powstają po zdarzeniu docelowym,
# - każdy klient występuje wiele razy,
# - 3% rekordów to duplikaty,
# - po 2026-01-01 występuje drift rozkładu.
