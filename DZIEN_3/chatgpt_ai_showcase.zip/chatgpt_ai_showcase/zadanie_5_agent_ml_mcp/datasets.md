# Dostępne zbiory

## churn_customers
Przewidywanie rezygnacji klienta. Silna nierównowaga klas, powtarzający się
klienci i możliwy przeciek czasowy. Koszt false negative jest pięć razy większy
niż false positive.

## loan_risk
Przewidywanie niewypłacalności. Mało danych, brakujące wartości i drift po
zmianie polityki kredytowej.

## sensor_failure
Wykrywanie awarii urządzeń. Dane szeregów czasowych i bardzo rzadka klasa awarii.
