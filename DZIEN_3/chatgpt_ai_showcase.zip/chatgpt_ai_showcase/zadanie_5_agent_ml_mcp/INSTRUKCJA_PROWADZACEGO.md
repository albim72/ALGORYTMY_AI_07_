# Zadanie 5: agent prowadzi eksperyment

`mock_mcp_server.py` jest deterministycznym symulatorem narzędzi. Dzięki temu
wynik pokazu nie zależy od czasu treningu ani przypadku.

Uruchom:

```bash
python mock_mcp_server.py
```

Następnie wysyłaj obiekty JSON z `demo_requests.jsonl` lub wykorzystaj
`mcp_tools.json` jako specyfikację narzędzi w swoim środowisku demonstracyjnym.

Najważniejszy moment: narzędzie `register_best_model` blokuje rejestrację,
dopóki `human_approved` nie ma wartości `true`.
