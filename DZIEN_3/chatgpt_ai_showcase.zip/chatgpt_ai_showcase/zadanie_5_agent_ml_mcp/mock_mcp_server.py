"""A deterministic MCP-style laboratory simulator.

It runs without external dependencies and accepts one JSON object per line:
{"tool": "list_datasets", "arguments": {}}
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import uuid


ROOT = Path(__file__).parent
STATE = json.loads((ROOT / "data" / "lab_state.json").read_text(encoding="utf-8"))
EXPERIMENTS: dict[str, dict] = {}


def call(tool: str, arguments: dict) -> dict:
    if tool == "list_datasets":
        return {"datasets": sorted(STATE["datasets"])}

    if tool == "inspect_dataset":
        dataset_id = arguments["dataset_id"]
        return {"dataset_id": dataset_id, **STATE["datasets"][dataset_id]}

    if tool == "train_model":
        name = arguments["parameters"].get("template", arguments["algorithm"])
        if name not in STATE["experiment_templates"]:
            return {"error": f"Unknown deterministic template: {name}"}
        experiment_id = f"exp-{uuid.uuid4().hex[:8]}"
        result = dict(STATE["experiment_templates"][name])
        result.update({
            "experiment_id": experiment_id,
            "dataset_id": arguments["dataset_id"],
            "algorithm": arguments["algorithm"],
            "parameters": arguments["parameters"],
        })
        EXPERIMENTS[experiment_id] = result
        return {"experiment_id": experiment_id, "status": "trained"}

    if tool == "evaluate_model":
        return EXPERIMENTS[arguments["experiment_id"]]

    if tool == "compare_experiments":
        selected = [EXPERIMENTS[item] for item in arguments["experiment_ids"]]
        best = min(selected, key=lambda item: item["cost"])
        return {
            "best_by_business_cost": best["experiment_id"],
            "comparison": selected,
            "warnings": [
                item.get("warning") for item in selected if item.get("warning")
            ],
        }

    if tool == "register_best_model":
        if not arguments.get("human_approved"):
            return {"status": "blocked", "reason": "Explicit human approval required"}
        return {"status": "registered", "experiment_id": arguments["experiment_id"]}

    return {"error": f"Unknown tool: {tool}"}


def main() -> None:
    for line in sys.stdin:
        request = json.loads(line)
        response = call(request["tool"], request.get("arguments", {}))
        print(json.dumps(response), flush=True)


if __name__ == "__main__":
    main()
